Ce dossier contient:

- Les images de l'accueil du site web
