Ce dossier contient:

- Les images du site web
- Des images remplaceant le contenu manquant du site web
